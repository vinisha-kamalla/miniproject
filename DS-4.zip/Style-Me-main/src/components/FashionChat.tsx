import React, { useState, useRef, useEffect } from "react";
import { GoogleGenAI } from "@google/genai";
import {
  Send,
  User,
  Bot,
  Image as ImageIcon,
  Loader2,
  Sparkles,
  Trash2,
  MessageSquare,
  CheckCircle2,
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import Markdown from "react-markdown";

interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  image?: string;
  timestamp: number;
}

export default function FashionChat() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setSelectedImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSend = async () => {
    if (!input.trim() && !selectedImage) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: "user",
      content: input,
      image: selectedImage || undefined,
      timestamp: Date.now(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInput("");
    const currentImage = selectedImage;
    setSelectedImage(null);
    setIsProcessing(true);
    setError(null);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
      const response = await ai.models.generateContent({
        model: "gemini-3.1-pro-preview",
        contents: [
          {
            parts: [
              {
                text: `You are a professional high-fashion stylist and image consultant for Style-ON. 
              Analyze the user's uploaded image (if provided) and their query.
              
              STRICT FORMATTING RULES:
              1. Use Markdown for all responses.
              2. Use **bold** for key fashion terms and recommendations.
              3. Use bullet points or numbered lists for steps or suggestions.
              4. Use headers (###) for distinct sections like "Color Palette" or "Silhouette Advice".
              5. Keep the tone sophisticated, encouraging, and authoritative.
              
              Focus on:
              - Body shape identification and flattering silhouettes.
              - Color theory (seasonal palettes, skin tone matching).
              - Specific outfit combinations for occasions.
              - Current high-fashion trends.
              
              If an image is provided, be extremely specific about what you see.
              If no image is provided, politely suggest they upload one for a "Neural Silhouette Analysis", but provide general expert advice in the meantime.
              
              User Query: ${input}`,
              },
              ...(currentImage
                ? [
                    {
                      inlineData: {
                        mimeType: "image/jpeg",
                        data: currentImage.split(",")[1],
                      },
                    },
                  ]
                : []),
            ],
          },
        ],
      });

      if (!response || !response.text) {
        throw new Error("No response from AI stylist");
      }

      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: "assistant",
        content: response.text,
        timestamp: Date.now(),
      };

      setMessages((prev) => [...prev, assistantMessage]);
    } catch (err: any) {
      console.error("Chat AI Error:", err);
      setError(
        err.message ||
          "Our stylist is currently at a fashion show. Please try again in a moment.",
      );
    } finally {
      setIsProcessing(false);
    }
  };

  const clearChat = () => {
    setMessages([]);
  };

  return (
    <div className="flex flex-col h-full bg-[#f0f2f5] overflow-hidden">
      {/* Header */}
      <div className="bg-fashion-black px-6 py-4 flex items-center justify-between text-white shadow-md z-10">
        <div className="flex items-center gap-4">
          <div className="w-10 h-10 rounded-full bg-fashion-gold flex items-center justify-center shadow-inner">
            <Bot size={24} className="text-white" />
          </div>
          <div>
            <h2 className="font-serif text-lg font-bold leading-tight">
              Style Concierge
            </h2>
            <div className="flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 bg-emerald-400 rounded-full animate-pulse" />
              <p className="text-[9px] font-bold uppercase tracking-widest text-emerald-400/80">
                Online
              </p>
            </div>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={clearChat}
            className="p-2 hover:bg-white/10 rounded-full transition-all text-white/60 hover:text-white"
            title="Clear Chat"
          >
            <Trash2 size={18} />
          </button>
        </div>
      </div>

      {/* Messages Area */}
      <div
        className="flex-1 overflow-y-auto p-4 md:px-10 md:py-6 space-y-4 custom-scrollbar relative"
        style={{
          backgroundImage: `url('https://www.transparenttextures.com/patterns/cubes.png')`,
          backgroundColor: "#e5ddd5",
        }}
      >
        <div className="max-w-4xl mx-auto space-y-4">
          {messages.length === 0 && (
            <div className="h-full flex flex-col items-center justify-center text-center p-12 space-y-8 mt-10">
              <motion.div
                animate={{
                  y: [0, -10, 0],
                }}
                transition={{
                  duration: 4,
                  repeat: Infinity,
                  ease: "easeInOut",
                }}
                className="w-20 h-20 bg-white rounded-full flex items-center justify-center text-fashion-gold shadow-sm"
              >
                <MessageSquare size={40} strokeWidth={1.5} />
              </motion.div>
              <div className="space-y-4 max-w-md bg-white/80 backdrop-blur-sm p-8 rounded-3xl shadow-sm border border-black/5">
                <h3 className="font-serif text-3xl font-bold text-fashion-black">
                  Welcome to <span className="text-fashion-gold">Style-ON</span>
                </h3>
                <p className="text-sm text-gray-600 leading-relaxed">
                  Your personal AI Style Concierge is ready. Ask for advice, or
                  upload a photo for a silhouette analysis.
                </p>
                <div className="flex flex-wrap justify-center gap-2 pt-4">
                  {[
                    "2026 Trends",
                    "Color Palette",
                    "Body Shape",
                    "Evening Wear",
                  ].map((tag) => (
                    <button
                      key={tag}
                      onClick={() => setInput(tag)}
                      className="px-4 py-2 bg-white hover:bg-fashion-gold hover:text-white border border-black/5 rounded-full text-[10px] font-bold uppercase tracking-widest text-gray-500 transition-all shadow-sm"
                    >
                      {tag}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          <AnimatePresence initial={false}>
            {messages.map((msg) => (
              <motion.div
                key={msg.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}
              >
                <div className={`max-w-[85%] md:max-w-[70%] relative group`}>
                  <div
                    className={`p-3 md:p-4 rounded-2xl shadow-sm text-[14px] leading-relaxed ${
                      msg.role === "user"
                        ? "bg-[#dcf8c6] text-fashion-black rounded-tr-none"
                        : "bg-white text-fashion-black rounded-tl-none"
                    }`}
                  >
                    {msg.image && (
                      <div className="mb-3 overflow-hidden rounded-xl border border-black/5">
                        <img
                          src={msg.image}
                          alt="User uploaded"
                          className="w-full max-w-[300px] object-cover"
                          referrerPolicy="no-referrer"
                        />
                      </div>
                    )}
                    <div className="markdown-body prose prose-sm max-w-none prose-fashion">
                      <Markdown>{msg.content}</Markdown>
                    </div>
                    <div className="flex items-center justify-end gap-1 mt-1 opacity-50">
                      <span className="text-[9px] font-medium">
                        {new Date(msg.timestamp).toLocaleTimeString([], {
                          hour: "2-digit",
                          minute: "2-digit",
                        })}
                      </span>
                      {msg.role === "user" && (
                        <CheckCircle2 size={10} className="text-blue-500" />
                      )}
                    </div>
                  </div>

                  {/* Tail for bubbles */}
                  <div
                    className={`absolute top-0 w-3 h-3 ${
                      msg.role === "user"
                        ? "-right-2 bg-[#dcf8c6] [clip-path:polygon(0_0,0_100%,100%_0)]"
                        : "-left-2 bg-white [clip-path:polygon(100%_0,100%_100%,0_0)]"
                    }`}
                  />
                </div>
              </motion.div>
            ))}
          </AnimatePresence>

          {isProcessing && (
            <div className="flex justify-start">
              <div className="max-w-[70%] bg-white p-4 rounded-2xl rounded-tl-none shadow-sm flex items-center gap-3 relative">
                <div className="flex gap-1">
                  <motion.div
                    animate={{ opacity: [0.4, 1, 0.4] }}
                    transition={{ repeat: Infinity, duration: 1 }}
                    className="w-1.5 h-1.5 bg-gray-400 rounded-full"
                  />
                  <motion.div
                    animate={{ opacity: [0.4, 1, 0.4] }}
                    transition={{ repeat: Infinity, duration: 1, delay: 0.2 }}
                    className="w-1.5 h-1.5 bg-gray-400 rounded-full"
                  />
                  <motion.div
                    animate={{ opacity: [0.4, 1, 0.4] }}
                    transition={{ repeat: Infinity, duration: 1, delay: 0.4 }}
                    className="w-1.5 h-1.5 bg-gray-400 rounded-full"
                  />
                </div>
                <span className="text-[11px] text-gray-400">typing...</span>
                <div className="absolute top-0 -left-2 w-3 h-3 bg-white [clip-path:polygon(100%_0,100%_100%,0_0)]" />
              </div>
            </div>
          )}

          {error && (
            <div className="flex justify-center">
              <div className="bg-red-50 text-red-500 text-[10px] font-bold uppercase tracking-widest px-4 py-2 rounded-lg border border-red-100 shadow-sm">
                {error}
              </div>
            </div>
          )}
        </div>

        <div ref={messagesEndRef} />
      </div>

      {/* Input Area */}
      <div className="bg-[#f0f2f5] p-3 md:p-4 border-t border-black/5">
        <div className="max-w-4xl mx-auto flex items-end gap-2">
          <div className="flex-1 bg-white rounded-[1.5rem] shadow-sm border border-black/5 overflow-hidden flex flex-col">
            <AnimatePresence>
              {selectedImage && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: "auto", opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  className="px-4 pt-4"
                >
                  <div className="relative inline-block">
                    <img
                      src={selectedImage}
                      alt="Preview"
                      className="w-20 h-20 object-cover rounded-xl border border-fashion-gold shadow-md"
                      referrerPolicy="no-referrer"
                    />
                    <button
                      onClick={() => setSelectedImage(null)}
                      className="absolute -top-2 -right-2 bg-fashion-black text-white rounded-full p-1.5 shadow-lg hover:bg-red-500 transition-all"
                    >
                      <Trash2 size={12} />
                    </button>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            <div className="flex items-end px-2">
              <button
                onClick={() => fileInputRef.current?.click()}
                className="p-3 text-gray-500 hover:text-fashion-gold transition-colors"
              >
                <ImageIcon size={22} />
              </button>
              <textarea
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter" && !e.shiftKey) {
                    e.preventDefault();
                    handleSend();
                  }
                }}
                placeholder="Type a message"
                rows={1}
                className="flex-1 bg-transparent border-none py-3 px-2 text-[15px] focus:outline-none resize-none max-h-32 custom-scrollbar"
                style={{ height: "auto" }}
                onInput={(e) => {
                  const target = e.target as HTMLTextAreaElement;
                  target.style.height = "auto";
                  target.style.height = `${target.scrollHeight}px`;
                }}
              />
              <input
                type="file"
                ref={fileInputRef}
                onChange={handleImageUpload}
                accept="image/*"
                className="hidden"
              />
            </div>
          </div>

          <button
            onClick={handleSend}
            disabled={isProcessing || (!input.trim() && !selectedImage)}
            className="w-12 h-12 flex-shrink-0 bg-fashion-gold text-white rounded-full flex items-center justify-center shadow-md hover:bg-fashion-gold/90 transition-all disabled:opacity-50 disabled:grayscale"
          >
            <Send size={20} />
          </button>
        </div>
      </div>
    </div>
  );
}
