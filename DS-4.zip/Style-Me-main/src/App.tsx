/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from "react";
import { GoogleGenAI } from "@google/genai";
import {
  Upload,
  Shirt,
  User,
  Sparkles,
  Loader2,
  RefreshCw,
  Download,
  Image as ImageIcon,
  History,
  Trash2,
  ChevronRight,
  Layers,
  Maximize2,
  Info,
  CheckCircle2,
  MessageSquare,
  Plus,
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import FashionChat from "./components/FashionChat";
import Auth from "./components/Auth";
import { auth, db } from "./firebase";
import {
  onAuthStateChanged,
  signOut,
  User as FirebaseUser,
} from "firebase/auth";
import {
  collection,
  addDoc,
  query,
  where,
  onSnapshot,
  deleteDoc,
  doc,
  orderBy,
  serverTimestamp,
  writeBatch,
  getDocs,
} from "firebase/firestore";

// Types and Interfaces
interface ImageState {
  file: File | null;
  preview: string | null;
}

interface HistoryItem {
  _id?: string;
  id: string;
  personPreview: string;
  clothingPreview: string;
  resultPreview: string;
  timestamp: number;
  fit: string;
}

interface UserData {
  id: string;
  email: string;
  name: string;
}

const CURATED_COLLECTIONS = [
  {
    category: "Women's Western",
    items: [
      {
        id: "ww1",
        name: "Silk Slip Dress",
        url: "https://images.unsplash.com/photo-1595777457583-95e059d581b8?q=80&w=600&auto=format&fit=crop",
      },
      {
        id: "ww2",
        name: "Leather Jacket",
        url: "https://images.unsplash.com/photo-1551028719-00167b16eac5?q=80&w=600&auto=format&fit=crop",
      },
      {
        id: "ww3",
        name: "Floral Maxi",
        url: "https://images.unsplash.com/photo-1496747611176-843222e1e57c?q=80&w=600&auto=format&fit=crop",
      },
      {
        id: "ww4",
        name: "Denim Jacket",
        url: "https://images.unsplash.com/photo-1544441893-675973e31985?q=80&w=600&auto=format&fit=crop",
      },
    ],
  },
  {
    category: "Women's Indian",
    items: [
      {
        id: "wi1",
        name: "Embroidered Saree",
        url: "https://images.unsplash.com/photo-1610030469983-98e550d6193c?q=80&w=600&auto=format&fit=crop",
      },
      {
        id: "wi2",
        name: "Anarkali Suit",
        url: "https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?q=80&w=600&auto=format&fit=crop",
      },
      {
        id: "wi3",
        name: "Lehenga Choli",
        url: "https://images.unsplash.com/photo-1599643478123-51145a51bc4c?q=80&w=600&auto=format&fit=crop",
      },
      {
        id: "wi4",
        name: "Chanderi Kurta",
        url: "https://images.unsplash.com/photo-1617627143750-d86bc21e42bb?q=80&w=600&auto=format&fit=crop",
      },
    ],
  },
  {
    category: "Men's Western",
    items: [
      {
        id: "mw1",
        name: "Classic Suit",
        url: "https://images.unsplash.com/photo-1594932224828-b4b057b69b82?q=80&w=600&auto=format&fit=crop",
      },
      {
        id: "mw2",
        name: "Bomber Jacket",
        url: "https://images.unsplash.com/photo-1591047139829-d91aecb6caea?q=80&w=600&auto=format&fit=crop",
      },
      {
        id: "mw3",
        name: "Flannel Shirt",
        url: "https://images.unsplash.com/photo-1596755094514-f87e34085b2c?q=80&w=600&auto=format&fit=crop",
      },
      {
        id: "mw4",
        name: "Graphic Tee",
        url: "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?q=80&w=600&auto=format&fit=crop",
      },
    ],
  },
  {
    category: "Men's Indian",
    items: [
      {
        id: "mi1",
        name: "Royal Sherwani",
        url: "https://images.unsplash.com/photo-1605518216938-7c31b7b14ad0?q=80&w=600&auto=format&fit=crop",
      },
      {
        id: "mi2",
        name: "Kurta Pajama",
        url: "https://images.unsplash.com/photo-1597983073493-88cd35cf93b0?q=80&w=600&auto=format&fit=crop",
      },
      {
        id: "mi3",
        name: "Nehru Jacket",
        url: "https://images.unsplash.com/photo-1621335829175-95f437384d7c?q=80&w=600&auto=format&fit=crop",
      },
      {
        id: "mi4",
        name: "Bandhgala",
        url: "https://images.unsplash.com/photo-1615233500621-4a0bb8a086bf?q=80&w=600&auto=format&fit=crop",
      },
    ],
  },
];

const FIT_OPTIONS = ["Standard", "Oversized", "Slim Fit", "Tucked In"];

const BRANDS = [
  "VOGUE",
  "GUCCI",
  "PRADA",
  "CHANEL",
  "DIOR",
  "HERMÈS",
  "VERSACE",
  "BALENCIAGA",
  "SAINT LAURENT",
];

const TRENDING_LOOKS = [
  {
    id: "t1",
    title: "Cyber Chic",
    color: "bg-blue-500",
    img: "https://images.unsplash.com/photo-1550684848-fac1c5b4e853?q=80&w=400",
  },
  {
    id: "t2",
    title: "Neon Retro",
    color: "bg-pink-500",
    img: "https://images.unsplash.com/photo-1529139513477-3235a14a1ec9?q=80&w=400",
  },
  {
    id: "t3",
    title: "Ethereal Silk",
    color: "bg-amber-400",
    img: "https://images.unsplash.com/photo-1490481651871-ab68de25d43d?q=80&w=400",
  },
  {
    id: "t4",
    title: "Urban Tech",
    color: "bg-emerald-500",
    img: "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?q=80&w=400",
  },
];

function BrandMarquee() {
  return (
    <div className="relative flex overflow-x-hidden bg-fashion-black py-12">
      <div className="animate-marquee whitespace-nowrap flex items-center">
        {[...BRANDS, ...BRANDS].map((brand, i) => (
          <span
            key={i}
            className="mx-12 text-4xl font-serif font-black tracking-[0.2em] text-white/20 hover:text-fashion-gold transition-colors cursor-default"
          >
            {brand}
          </span>
        ))}
      </div>
    </div>
  );
}

export default function App() {
  const [user, setUser] = useState<FirebaseUser | null>(null);
  const [isAuthReady, setIsAuthReady] = useState(false);
  const [personImage, setPersonImage] = useState<ImageState>({
    file: null,
    preview: null,
  });
  const [clothingImage, setClothingImage] = useState<ImageState>({
    file: null,
    preview: null,
  });
  const [resultImage, setResultImage] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [fitStyle, setFitStyle] = useState("Standard");
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [showComparison, setShowComparison] = useState(false);
  const [activeTab, setActiveTab] = useState<"create" | "history" | "chat">(
    "create",
  );
  const [showClearConfirm, setShowClearConfirm] = useState(false);
  const [cooldown, setCooldown] = useState(0);
  const [retryCount, setRetryCount] = useState(0);
  const [lastErrorDetails, setLastErrorDetails] = useState<string | null>(null);
  const [loadingMessage, setLoadingMessage] = useState(
    "Analyzing your style...",
  );

  const loadingMessages = [
    "Analyzing your style...",
    "Scanning garment textures...",
    "Adjusting fit and drape...",
    "Matching lighting conditions...",
    "Finalizing your digital twin...",
    "Polishing the final look...",
  ];

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isProcessing) {
      let i = 0;
      interval = setInterval(() => {
        i = (i + 1) % loadingMessages.length;
        setLoadingMessage(loadingMessages[i]);
      }, 3000);
    }
    return () => clearInterval(interval);
  }, [isProcessing]);

  const personInputRef = useRef<HTMLInputElement>(null);
  const clothingInputRef = useRef<HTMLInputElement>(null);

  // Cooldown timer
  useEffect(() => {
    if (cooldown > 0) {
      const timer = setTimeout(() => setCooldown(cooldown - 1), 1000);
      return () => clearTimeout(timer);
    }
  }, [cooldown]);

  // Auth Listener
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
      setIsAuthReady(true);
    });
    return () => unsubscribe();
  }, []);

  // Load history from Firestore
  useEffect(() => {
    if (user) {
      const q = query(
        collection(db, "history"),
        where("userId", "==", user.uid),
        orderBy("timestamp", "desc"),
      );

      const unsubscribe = onSnapshot(
        q,
        (snapshot) => {
          const items = snapshot.docs.map((doc) => ({
            id: doc.id,
            ...doc.data(),
          })) as any[];
          setHistory(items);
        },
        (err) => {
          console.error("Firestore error:", err);
        },
      );

      return () => unsubscribe();
    } else {
      setHistory([]);
    }
  }, [user]);

  const handleAuthSuccess = (firebaseUser: FirebaseUser) => {
    setUser(firebaseUser);
  };

  const handleLogout = async () => {
    try {
      await signOut(auth);
      setHistory([]);
      setActiveTab("create");
    } catch (e) {
      console.error("Logout error", e);
    }
  };

  const handleImageUpload = (
    e: React.ChangeEvent<HTMLInputElement>,
    type: "person" | "clothing",
  ) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const state = { file, preview: reader.result as string };
        if (type === "person") setPersonImage(state);
        else setClothingImage(state);
      };
      reader.readAsDataURL(file);
    }
  };

  const selectSampleGarment = async (url: string) => {
    try {
      // Use Image object to load cross-origin images more reliably
      const img = new Image();
      img.crossOrigin = "anonymous";
      img.src = url;

      await new Promise((resolve, reject) => {
        img.onload = resolve;
        img.onerror = () =>
          reject(
            new Error(
              "Failed to load image from source. This may be due to CORS restrictions.",
            ),
          );
      });

      const canvas = document.createElement("canvas");
      canvas.width = img.width;
      canvas.height = img.height;
      const ctx = canvas.getContext("2d");
      ctx?.drawImage(img, 0, 0);

      canvas.toBlob((blob) => {
        if (blob) {
          const file = new File([blob], "sample.jpg", { type: "image/jpeg" });
          const reader = new FileReader();
          reader.onloadend = () => {
            setClothingImage({ file, preview: reader.result as string });
          };
          reader.readAsDataURL(file);
        } else {
          setError("Failed to process sample image.");
        }
      }, "image/jpeg");
    } catch (err) {
      console.error("Sample load error:", err);
      setError(
        "Failed to load sample garment. Please try uploading your own image.",
      );
    }
  };

  const resizeImage = (
    file: File,
    maxDimension: number = 1024,
  ): Promise<{ data: string; aspectRatio: string }> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = (event) => {
        const img = new Image();
        img.src = event.target?.result as string;
        img.onload = () => {
          const canvas = document.createElement("canvas");
          let width = img.width;
          let height = img.height;

          // Calculate closest supported aspect ratio for Gemini
          const ratio = width / height;
          const supported = [
            { name: "1:1", val: 1 },
            { name: "3:4", val: 3 / 4 },
            { name: "4:3", val: 4 / 3 },
            { name: "9:16", val: 9 / 16 },
            { name: "16:9", val: 16 / 9 },
          ];
          const closestRatio = supported.reduce((prev, curr) =>
            Math.abs(curr.val - ratio) < Math.abs(prev.val - ratio)
              ? curr
              : prev,
          ).name;

          if (width > height) {
            if (width > maxDimension) {
              height *= maxDimension / width;
              width = maxDimension;
            }
          } else {
            if (height > maxDimension) {
              width *= maxDimension / height;
              height = maxDimension;
            }
          }

          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext("2d");
          ctx?.drawImage(img, 0, 0, width, height);

          const dataUrl = canvas.toDataURL("image/jpeg", 0.8);
          resolve({
            data: dataUrl.split(",")[1],
            aspectRatio: closestRatio,
          });
        };
        img.onerror = reject;
      };
      reader.onerror = reject;
    });
  };

  const createThumbnail = (
    dataUrl: string,
    maxDim: number = 400,
  ): Promise<string> => {
    return new Promise((resolve) => {
      const img = new Image();
      img.src = dataUrl;
      img.onload = () => {
        const canvas = document.createElement("canvas");
        let width = img.width;
        let height = img.height;

        if (width > height) {
          if (width > maxDim) {
            height *= maxDim / width;
            width = maxDim;
          }
        } else {
          if (height > maxDim) {
            width *= maxDim / height;
            height = maxDim;
          }
        }

        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext("2d");
        ctx?.drawImage(img, 0, 0, width, height);
        resolve(canvas.toDataURL("image/jpeg", 0.7));
      };
      img.onerror = () => resolve(dataUrl); // Fallback to original if error
    });
  };

  const handleTryOn = async () => {
    if (cooldown > 0) return;

    if (!personImage.file || !clothingImage.file) {
      setError("Please upload both a person image and a clothing image.");
      return;
    }

    setIsProcessing(true);
    setError(null);
    setResultImage(null);

    try {
      const maxDim = retryCount > 0 ? 800 : 1024;
      const personResult = await resizeImage(personImage.file, maxDim);
      const clothingResult = await resizeImage(clothingImage.file, maxDim);

      const apiKey = process.env.GEMINI_API_KEY;
      if (!apiKey) {
        throw new Error(
          "API Key is missing. Please check your environment configuration.",
        );
      }

      const ai = new GoogleGenAI({ apiKey });

      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash-image",
        contents: {
          parts: [
            {
              inlineData: {
                data: personResult.data,
                mimeType: personImage.file.type || "image/jpeg",
              },
            },
            {
              inlineData: {
                data: clothingResult.data,
                mimeType: clothingImage.file.type || "image/jpeg",
              },
            },
            {
              text: `This is a virtual try-on request. Please take the clothing from the second image and realistically place it on the person in the first image. 
              Fit Style: ${fitStyle}. 
              Ensure the fit is natural, matching the person's pose and body shape. The output should be a high-quality image of the person wearing the new garment.
              IMPORTANT: The output image must maintain the full length and aspect ratio of the person in the first image. Do not crop or cut off the person.`,
            },
          ],
        },
        config: {
          imageConfig: {
            aspectRatio: personResult.aspectRatio as any,
          },
        },
      });

      if (
        !response ||
        !response.candidates ||
        response.candidates.length === 0
      ) {
        throw new Error("No response from AI model.");
      }

      let foundImage = false;
      const parts = response.candidates[0].content?.parts || [];
      for (const part of parts) {
        if (part.inlineData) {
          const resultUrl = `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
          setResultImage(resultUrl);

          // Create thumbnails for history to save localStorage space
          const [personThumb, clothingThumb, resultThumb] = await Promise.all([
            createThumbnail(personImage.preview!, 300),
            createThumbnail(clothingImage.preview!, 300),
            createThumbnail(resultUrl, 600),
          ]);

          // Add to history (Firestore)
          if (user) {
            try {
              await addDoc(collection(db, "history"), {
                userId: user.uid,
                personPreview: personThumb,
                clothingPreview: clothingThumb,
                resultPreview: resultThumb,
                fit: fitStyle,
                timestamp: serverTimestamp(),
              });
            } catch (e) {
              console.error("Failed to save to Firestore", e);
            }
          }

          setRetryCount(0);
          setLastErrorDetails(null);

          foundImage = true;
          break;
        }
      }

      if (!foundImage) {
        throw new Error(
          "The AI did not return an image. Please try different photos.",
        );
      }
    } catch (err: any) {
      console.error("AI Error:", err);
      setRetryCount((prev) => prev + 1);

      // Improved error detection for 429/Quota errors
      let errorMessage = "";
      let isQuotaError = false;
      let errorString = "";

      try {
        errorMessage = err.message || (err.error && err.error.message) || "";
        const errorStatus =
          err.status ||
          (err.response && err.response.status) ||
          (err.error && err.error.code);
        errorString = JSON.stringify(err);
        setLastErrorDetails(errorString);

        isQuotaError =
          errorStatus === 429 ||
          errorStatus === "RESOURCE_EXHAUSTED" ||
          errorMessage.includes("429") ||
          errorMessage.includes("RESOURCE_EXHAUSTED") ||
          errorMessage.toLowerCase().includes("quota") ||
          errorString.includes("429") ||
          errorString.includes("RESOURCE_EXHAUSTED");
      } catch (e) {
        console.error("Error parsing AI error:", e);
      }

      if (isQuotaError) {
        const isHardLimit =
          errorMessage.toLowerCase().includes("daily") ||
          errorString.toLowerCase().includes("daily") ||
          errorMessage.toLowerCase().includes("plan and billing") ||
          errorMessage.toLowerCase().includes("exceeded your current quota");

        if (isHardLimit) {
          setError(
            "Daily AI Quota reached. The free tier has a limited number of generations per day. Please try again tomorrow or check your Google AI Studio billing settings.",
          );
        } else {
          // Increase cooldown if it keeps happening
          const waitTime = retryCount > 0 ? 120 : 60;
          setError(
            `AI Rate Limit reached. Please wait ${waitTime} seconds for the limit to reset.`,
          );
          setCooldown(waitTime);
        }
      } else {
        setError(
          errorMessage ||
            "An error occurred during processing. Please try again.",
        );
      }
    } finally {
      setIsProcessing(false);
    }
  };

  const deleteHistoryItem = async (id: string) => {
    try {
      await deleteDoc(doc(db, "history", id));
    } catch (e) {
      console.error("Failed to delete from Firestore", e);
    }
  };

  const clearHistory = async () => {
    if (!user) return;
    try {
      const q = query(
        collection(db, "history"),
        where("userId", "==", user.uid),
      );
      const snapshot = await getDocs(q);
      const batch = writeBatch(db);
      snapshot.docs.forEach((d) => {
        batch.delete(d.ref);
      });
      await batch.commit();
      setShowClearConfirm(false);
    } catch (e) {
      console.error("Failed to clear history from Firestore", e);
    }
  };

  const reset = () => {
    setPersonImage({ file: null, preview: null });
    setClothingImage({ file: null, preview: null });
    setResultImage(null);
    setError(null);
    setShowComparison(false);
  };

  if (!isAuthReady) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-fashion-cream">
        <Loader2 className="animate-spin text-fashion-gold" size={48} />
      </div>
    );
  }

  if (!user) {
    return <Auth onAuthSuccess={handleAuthSuccess} />;
  }

  return (
    <div className="min-h-screen bg-fashion-cream font-sans text-fashion-black">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 border-b border-black/5 bg-white/70 backdrop-blur-xl">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-4">
          <div className="flex items-center gap-3">
            <div className="flex h-12 w-12 items-center justify-center rounded-full bg-fashion-black text-white shadow-2xl shadow-black/20">
              <Sparkles size={24} className="text-fashion-gold" />
            </div>
            <div>
              <h1 className="font-serif text-xl font-bold tracking-tight leading-none">
                STYLE-ON
              </h1>
              <p className="text-[9px] font-bold uppercase tracking-[0.3em] text-gray-400 mt-1">
                Haute Couture AI
              </p>
            </div>
          </div>

          <div className="hidden items-center gap-1 rounded-full bg-black/5 p-1 md:flex">
            <button
              onClick={() => setActiveTab("create")}
              className={`flex items-center gap-2 rounded-full px-6 py-2 text-xs font-bold uppercase tracking-widest transition-all ${
                activeTab === "create"
                  ? "bg-white text-black shadow-lg"
                  : "text-gray-400 hover:text-black"
              }`}
            >
              <Shirt size={14} />
              Studio
            </button>
            <button
              onClick={() => setActiveTab("chat")}
              className={`flex items-center gap-2 rounded-full px-6 py-2 text-xs font-bold uppercase tracking-widest transition-all ${
                activeTab === "chat"
                  ? "bg-white text-black shadow-lg"
                  : "text-gray-400 hover:text-black"
              }`}
            >
              <MessageSquare size={14} />
              Stylist
            </button>
            <button
              onClick={() => setActiveTab("history")}
              className={`flex items-center gap-2 rounded-full px-6 py-2 text-xs font-bold uppercase tracking-widest transition-all ${
                activeTab === "history"
                  ? "bg-white text-black shadow-lg"
                  : "text-gray-400 hover:text-black"
              }`}
            >
              <History size={14} />
              Gallery
            </button>
          </div>

          <div className="flex items-center gap-4">
            <button
              onClick={reset}
              className="flex h-10 w-10 items-center justify-center rounded-full border border-black/5 bg-white text-gray-400 transition-all hover:border-black hover:text-black"
              title="Reset Studio"
            >
              <RefreshCw size={16} />
            </button>
            <div className="h-8 w-px bg-black/5" />
            <div className="flex items-center gap-3">
              <div className="hidden text-right md:block">
                <p className="text-[10px] font-bold uppercase tracking-widest text-gray-900">
                  {user.displayName || user.email}
                </p>
                <button
                  onClick={handleLogout}
                  className="text-[8px] font-bold uppercase tracking-widest text-fashion-accent hover:underline"
                >
                  Logout
                </button>
              </div>
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-fashion-gold/10 text-fashion-gold">
                {user.photoURL ? (
                  <img
                    src={user.photoURL}
                    className="w-full h-full rounded-full object-cover"
                    alt="Profile"
                  />
                ) : (
                  <User size={18} />
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Mobile Nav */}
        <div className="flex border-t border-black/5 bg-white/50 p-1 md:hidden">
          <button
            onClick={() => setActiveTab("create")}
            className={`flex-1 py-3 text-[10px] font-bold uppercase tracking-widest ${activeTab === "create" ? "text-black" : "text-gray-400"}`}
          >
            Studio
          </button>
          <button
            onClick={() => setActiveTab("chat")}
            className={`flex-1 py-3 text-[10px] font-bold uppercase tracking-widest ${activeTab === "chat" ? "text-black" : "text-gray-400"}`}
          >
            Stylist
          </button>
          <button
            onClick={() => setActiveTab("history")}
            className={`flex-1 py-3 text-[10px] font-bold uppercase tracking-widest ${activeTab === "history" ? "text-black" : "text-gray-400"}`}
          >
            Gallery
          </button>
        </div>
      </nav>

      <main
        className={`${activeTab === "chat" ? "w-full h-[calc(100vh-80px)] overflow-hidden" : "mx-auto max-w-7xl px-6 py-12"}`}
      >
        <AnimatePresence mode="wait">
          {activeTab === "create" ? (
            <motion.div
              key="studio"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="space-y-16"
            >
              {/* Hero Section */}
              <section className="relative overflow-hidden rounded-[3rem] fashion-gradient p-12 lg:p-20">
                <div className="relative z-10 grid gap-12 lg:grid-cols-2 lg:items-center">
                  <div className="space-y-8">
                    <motion.div
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: 0.2 }}
                    >
                      <span className="inline-block rounded-full border border-white/20 bg-white/10 px-4 py-1.5 text-[10px] font-bold uppercase tracking-[0.3em] text-fashion-gold">
                        The Future of Fashion
                      </span>
                      <h2 className="mt-6 font-serif text-5xl font-light leading-[1.1] text-white lg:text-7xl">
                        Your{" "}
                        <span className="italic text-fashion-gold">
                          Digital
                        </span>{" "}
                        <br />
                        Wardrobe <span className="font-bold">Awaits</span>
                      </h2>
                      <p className="mt-8 max-w-md text-lg leading-relaxed text-gray-400">
                        Experience garments with professional realism. Our
                        neural engine adapts any piece to your unique silhouette
                        instantly.
                      </p>
                    </motion.div>

                    <div className="flex flex-wrap gap-4">
                      <button
                        onClick={() => personInputRef.current?.click()}
                        className="rounded-full bg-white px-8 py-4 text-xs font-bold uppercase tracking-widest text-black transition-all hover:scale-105 hover:shadow-2xl active:scale-95"
                      >
                        Start Creating
                      </button>
                      <button
                        onClick={() => setActiveTab("chat")}
                        className="rounded-full border border-white/20 bg-white/5 px-8 py-4 text-xs font-bold uppercase tracking-widest text-white backdrop-blur-md transition-all hover:bg-white/10"
                      >
                        Consult Stylist
                      </button>
                    </div>
                  </div>

                  <div className="relative hidden lg:block">
                    <div className="absolute -right-20 -top-20 h-96 w-96 rounded-full bg-fashion-gold/20 blur-[100px]" />
                    <div className="grid grid-cols-2 gap-4">
                      <motion.div
                        animate={{ y: [0, -20, 0] }}
                        transition={{
                          duration: 4,
                          repeat: Infinity,
                          ease: "easeInOut",
                        }}
                        className="aspect-[3/4] overflow-hidden rounded-3xl border border-white/10 shadow-2xl"
                      >
                        <img
                          src="https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?q=80&w=500"
                          alt="Fashion 1"
                          className="h-full w-full object-cover"
                          referrerPolicy="no-referrer"
                        />
                      </motion.div>
                      <motion.div
                        animate={{ y: [0, 20, 0] }}
                        transition={{
                          duration: 4,
                          repeat: Infinity,
                          ease: "easeInOut",
                          delay: 1,
                        }}
                        className="mt-12 aspect-[3/4] overflow-hidden rounded-3xl border border-white/10 shadow-2xl"
                      >
                        <img
                          src="https://images.unsplash.com/photo-1539109136881-3be0616acf4b?q=80&w=500"
                          alt="Fashion 2"
                          className="h-full w-full object-cover"
                          referrerPolicy="no-referrer"
                        />
                      </motion.div>
                    </div>
                  </div>
                </div>
              </section>

              <BrandMarquee />

              {/* Fashion Tip Section */}
              <section className="rounded-[3rem] bg-fashion-gold/10 p-12 border border-fashion-gold/20 relative overflow-hidden">
                <div className="absolute top-0 right-0 -translate-y-1/2 translate-x-1/2 w-64 h-64 bg-fashion-gold/20 rounded-full blur-3xl" />
                <div className="relative z-10 flex flex-col md:flex-row items-center gap-12">
                  <div className="w-24 h-24 rounded-full bg-fashion-gold flex items-center justify-center text-white shrink-0 shadow-2xl">
                    <Sparkles size={48} />
                  </div>
                  <div className="space-y-4">
                    <span className="text-[10px] font-bold uppercase tracking-[0.3em] text-fashion-gold">
                      Style-ON Intelligence
                    </span>
                    <h3 className="font-serif text-3xl font-bold">
                      Stylist's Tip of the Day
                    </h3>
                    <p className="text-lg text-gray-600 italic leading-relaxed">
                      "Monochromatic dressing in neutral tones like cream and
                      beige creates an elongated, sophisticated silhouette. Add
                      a pop of gold jewelry to elevate the look for evening
                      events."
                    </p>
                  </div>
                </div>
              </section>

              {/* Trending Section */}
              <section className="space-y-8">
                <div className="flex items-end justify-between">
                  <div>
                    <span className="text-[10px] font-bold uppercase tracking-[0.3em] text-fashion-gold">
                      Curated for you
                    </span>
                    <h3 className="mt-2 font-serif text-4xl font-bold">
                      Trending Aesthetics
                    </h3>
                  </div>
                  <button className="text-xs font-bold uppercase tracking-widest text-gray-400 hover:text-black transition-colors">
                    View Editorial
                  </button>
                </div>

                <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
                  {TRENDING_LOOKS.map((look, i) => (
                    <motion.div
                      key={look.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: i * 0.1 }}
                      className="group relative aspect-[4/5] overflow-hidden rounded-[2rem] cursor-pointer"
                    >
                      <img
                        src={look.img}
                        alt={look.title}
                        className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-110"
                        referrerPolicy="no-referrer"
                      />
                      <div
                        className={`absolute inset-0 ${look.color} mix-blend-multiply opacity-20 transition-opacity group-hover:opacity-40`}
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
                      <div className="absolute bottom-8 left-8">
                        <p className="text-[10px] font-bold uppercase tracking-widest text-white/60">
                          Season 2026
                        </p>
                        <h4 className="mt-1 font-serif text-xl font-bold text-white">
                          {look.title}
                        </h4>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </section>

              <div className="grid gap-12 lg:grid-cols-3">
                {/* Column 1: Choose Model */}
                <div className="space-y-8">
                  <div className="flex items-center gap-4">
                    <div className="flex h-10 w-10 items-center justify-center rounded-full bg-fashion-black text-white font-serif text-sm font-bold">
                      01
                    </div>
                    <label className="font-serif text-sm font-bold uppercase tracking-widest text-gray-900">
                      Choose Model
                    </label>
                    {personImage.preview && (
                      <button
                        onClick={() =>
                          setPersonImage({ file: null, preview: null })
                        }
                        className="ml-auto text-[10px] font-bold text-fashion-accent hover:underline tracking-widest"
                      >
                        RESET
                      </button>
                    )}
                  </div>

                  <div
                    onClick={() => personInputRef.current?.click()}
                    className={`group relative flex cursor-pointer flex-col items-center justify-center overflow-hidden rounded-[2.5rem] border-2 border-dashed transition-all duration-700 ${
                      personImage.preview
                        ? "border-transparent shadow-2xl bg-white"
                        : "aspect-[3/4] border-black/5 bg-white hover:border-fashion-gold hover:bg-fashion-gold/5"
                    }`}
                  >
                    {personImage.preview ? (
                      <div className="relative w-full">
                        <img
                          src={personImage.preview}
                          alt="Person"
                          className="w-full h-auto max-h-[600px] object-contain transition-transform duration-1000 group-hover:scale-105"
                          referrerPolicy="no-referrer"
                        />
                        <div className="absolute inset-0 flex items-center justify-center bg-fashion-black/40 opacity-0 transition-opacity group-hover:opacity-100">
                          <div className="rounded-full bg-white/20 p-4 backdrop-blur-xl">
                            <Upload className="text-white" size={24} />
                          </div>
                        </div>
                      </div>
                    ) : (
                      <div className="flex flex-col items-center gap-4 text-gray-300 transition-colors group-hover:text-fashion-gold">
                        <div className="rounded-full bg-gray-50 p-6 transition-all group-hover:bg-fashion-gold group-hover:text-white group-hover:shadow-xl">
                          <User size={32} strokeWidth={1} />
                        </div>
                        <div className="text-center px-6">
                          <p className="text-xs font-bold uppercase tracking-widest">
                            Upload Portrait
                          </p>
                          <p className="mt-1 text-[10px] opacity-60">
                            Full body or portrait
                          </p>
                        </div>
                      </div>
                    )}
                    <input
                      type="file"
                      ref={personInputRef}
                      className="hidden"
                      accept="image/*"
                      onChange={(e) => handleImageUpload(e, "person")}
                    />
                  </div>

                  <div className="rounded-3xl bg-white/50 p-6 border border-black/5 backdrop-blur-sm">
                    <div className="flex items-center gap-2 text-fashion-gold mb-3">
                      <Info size={14} />
                      <span className="text-[10px] font-bold uppercase tracking-widest">
                        Studio Guidance
                      </span>
                    </div>
                    <p className="text-[11px] leading-relaxed text-gray-500">
                      For the most realistic results, ensure the model is
                      standing in a neutral pose with clear visibility of the
                      torso and limbs.
                    </p>
                  </div>
                </div>

                {/* Column 2: Select Garment & Controls */}
                <div className="space-y-8">
                  <div className="flex items-center gap-4">
                    <div className="flex h-10 w-10 items-center justify-center rounded-full bg-fashion-black text-white font-serif text-sm font-bold">
                      02
                    </div>
                    <label className="font-serif text-sm font-bold uppercase tracking-widest text-gray-900">
                      Select Garment
                    </label>
                    {clothingImage.preview && (
                      <button
                        onClick={() =>
                          setClothingImage({ file: null, preview: null })
                        }
                        className="ml-auto text-[10px] font-bold text-fashion-accent hover:underline tracking-widest"
                      >
                        RESET
                      </button>
                    )}
                  </div>

                  <div
                    onClick={() => clothingInputRef.current?.click()}
                    className={`group relative flex cursor-pointer flex-col items-center justify-center overflow-hidden rounded-[2.5rem] border-2 border-dashed transition-all duration-700 ${
                      clothingImage.preview
                        ? "border-transparent shadow-2xl bg-white"
                        : "aspect-[3/4] border-black/5 bg-white hover:border-fashion-gold hover:bg-fashion-gold/5"
                    }`}
                  >
                    {clothingImage.preview ? (
                      <div className="relative w-full">
                        <img
                          src={clothingImage.preview}
                          alt="Clothing"
                          className="w-full h-auto max-h-[600px] object-contain transition-transform duration-1000 group-hover:scale-105"
                          referrerPolicy="no-referrer"
                        />
                        <div className="absolute inset-0 flex items-center justify-center bg-fashion-black/40 opacity-0 transition-opacity group-hover:opacity-100">
                          <div className="rounded-full bg-white/20 p-4 backdrop-blur-xl">
                            <Upload className="text-white" size={24} />
                          </div>
                        </div>
                      </div>
                    ) : (
                      <div className="flex flex-col items-center gap-4 text-gray-300 transition-colors group-hover:text-fashion-gold">
                        <div className="rounded-full bg-gray-50 p-6 transition-all group-hover:bg-fashion-gold group-hover:text-white group-hover:shadow-xl">
                          <Shirt size={32} strokeWidth={1} />
                        </div>
                        <div className="text-center px-6">
                          <p className="text-xs font-bold uppercase tracking-widest">
                            Upload Item
                          </p>
                          <p className="mt-1 text-[10px] opacity-60">
                            Flat lay or ghost mannequin
                          </p>
                        </div>
                      </div>
                    )}
                    <input
                      type="file"
                      ref={clothingInputRef}
                      className="hidden"
                      accept="image/*"
                      onChange={(e) => handleImageUpload(e, "clothing")}
                    />
                  </div>

                  <div className="space-y-8">
                    <div className="flex items-center justify-between">
                      <h4 className="font-serif text-[10px] font-bold uppercase tracking-widest text-gray-400">
                        Curated Collection
                      </h4>
                      <span className="text-[9px] text-gray-300">
                        Quick Select
                      </span>
                    </div>

                    <div className="space-y-8">
                      {CURATED_COLLECTIONS.map((collection) => (
                        <div
                          key={collection.category}
                          className="space-y-3 pb-6 border-b border-black/5 last:border-0 last:pb-0"
                        >
                          <h5 className="text-[9px] font-bold uppercase tracking-widest text-fashion-gold/80 ml-1">
                            {collection.category}
                          </h5>
                          <div className="flex flex-wrap gap-3">
                            {collection.items.map((item) => (
                              <div
                                key={item.id}
                                className="flex flex-col items-center space-y-1"
                              >
                                <button
                                  onClick={() => selectSampleGarment(item.url)}
                                  className="group relative h-16 w-16 overflow-hidden rounded-2xl border border-black/5 bg-white transition-all hover:border-fashion-gold hover:shadow-xl"
                                  title={item.name}
                                >
                                  <img
                                    src={item.url}
                                    alt={item.name}
                                    className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-125"
                                    referrerPolicy="no-referrer"
                                    onError={(e) => {
                                      (e.target as HTMLImageElement).src =
                                        `https://picsum.photos/seed/${item.id}/200/200`;
                                    }}
                                  />
                                  <div className="absolute inset-0 flex items-center justify-center bg-fashion-gold/20 opacity-0 transition-opacity group-hover:opacity-100">
                                    <Plus size={16} className="text-white" />
                                  </div>
                                </button>
                                <span className="text-[7px] font-medium text-gray-400 uppercase tracking-tighter text-center w-16 truncate">
                                  {item.name}
                                </span>
                              </div>
                            ))}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="space-y-6 rounded-[2.5rem] bg-white p-8 shadow-2xl shadow-black/5 border border-black/5">
                    <div className="space-y-4">
                      <label className="font-serif text-[10px] font-bold uppercase tracking-widest text-gray-400">
                        Silhouette Fit
                      </label>
                      <div className="grid grid-cols-2 gap-2">
                        {FIT_OPTIONS.map((option) => (
                          <button
                            key={option}
                            onClick={() => setFitStyle(option)}
                            className={`rounded-xl py-3 text-[9px] font-bold uppercase tracking-widest transition-all ${
                              fitStyle === option
                                ? "bg-fashion-black text-white shadow-lg"
                                : "bg-gray-50 text-gray-400 hover:bg-gray-100"
                            }`}
                          >
                            {option}
                          </button>
                        ))}
                      </div>
                    </div>

                    <button
                      onClick={handleTryOn}
                      disabled={
                        isProcessing ||
                        !personImage.file ||
                        !clothingImage.file ||
                        cooldown > 0
                      }
                      className="group relative flex w-full items-center justify-center gap-3 overflow-hidden rounded-2xl bg-fashion-black py-5 text-[11px] font-bold uppercase tracking-[0.3em] text-white transition-all hover:bg-zinc-800 hover:shadow-2xl disabled:cursor-not-allowed disabled:opacity-50"
                    >
                      <div className="absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-white/10 to-transparent transition-transform duration-1000 group-hover:translate-x-full" />
                      {isProcessing ? (
                        <>
                          <Loader2 className="animate-spin" size={18} />
                          Synthesizing...
                        </>
                      ) : cooldown > 0 ? (
                        <>
                          <RefreshCw className="animate-spin" size={18} />
                          Wait {cooldown}s
                        </>
                      ) : (
                        <>
                          <Sparkles
                            size={18}
                            className="text-fashion-gold transition-transform group-hover:scale-125"
                          />
                          Generate Look
                        </>
                      )}
                    </button>

                    {error && (
                      <motion.div
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="flex items-start gap-3 rounded-2xl bg-fashion-accent/5 p-5 text-[10px] font-medium text-fashion-accent border border-fashion-accent/10"
                      >
                        <Info size={16} className="shrink-0" />
                        <p className="leading-relaxed opacity-80">{error}</p>
                      </motion.div>
                    )}
                  </div>
                </div>

                {/* Column 3: Result Display */}
                <div className="space-y-8">
                  <div className="flex items-center gap-4">
                    <div className="flex h-10 w-10 items-center justify-center rounded-full bg-fashion-black text-white font-serif text-sm font-bold">
                      03
                    </div>
                    <label className="font-serif text-sm font-bold uppercase tracking-widest text-gray-900">
                      Output Image
                    </label>
                  </div>

                  <div className="relative lg:sticky lg:top-32 min-h-[500px] w-full overflow-hidden rounded-[3rem] bg-white shadow-2xl shadow-black/10 border border-black/5">
                    <AnimatePresence mode="wait">
                      {resultImage ? (
                        <motion.div
                          key="result-container"
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          className="flex h-full w-full items-center justify-center"
                        >
                          {showComparison ? (
                            <div className="grid h-full w-full grid-cols-2 gap-0.5 bg-gray-100">
                              <div className="relative overflow-hidden bg-fashion-cream">
                                <img
                                  src={personImage.preview!}
                                  alt="Original"
                                  className="h-full w-full object-contain"
                                  referrerPolicy="no-referrer"
                                />
                                <span className="absolute bottom-6 left-6 rounded-full bg-black/60 px-4 py-1.5 text-[8px] font-bold tracking-[0.2em] text-white backdrop-blur-md">
                                  ORIGINAL
                                </span>
                              </div>
                              <div className="relative overflow-hidden bg-fashion-cream">
                                <img
                                  src={resultImage}
                                  alt="Result"
                                  className="h-full w-full object-contain"
                                  referrerPolicy="no-referrer"
                                />
                                <span className="absolute bottom-6 left-6 rounded-full bg-fashion-gold/80 px-4 py-1.5 text-[8px] font-bold tracking-[0.2em] text-white backdrop-blur-md">
                                  RESULT
                                </span>
                              </div>
                            </div>
                          ) : (
                            <div className="relative h-full w-full bg-fashion-cream flex items-center justify-center">
                              <img
                                src={resultImage}
                                alt="Result"
                                className="w-full h-auto max-h-full object-contain"
                                referrerPolicy="no-referrer"
                              />
                            </div>
                          )}

                          <div className="absolute right-6 top-6 flex flex-col gap-4">
                            <button
                              onClick={() => setShowComparison(!showComparison)}
                              className={`flex h-14 w-14 items-center justify-center rounded-full shadow-2xl transition-all backdrop-blur-xl ${
                                showComparison
                                  ? "bg-fashion-gold text-white"
                                  : "bg-white/90 text-black hover:bg-white"
                              }`}
                              title="Toggle Comparison"
                            >
                              <Layers size={24} />
                            </button>
                            <button
                              onClick={() => {
                                const win = window.open();
                                if (win) {
                                  win.document.write(`
                                    <html>
                                      <head><title>Style-ON Result</title></head>
                                      <body style="margin:0; background:#fdfcf8; display:flex; align-items:center; justify-content:center; min-height:100vh;">
                                        <img src="${resultImage}" style="max-width: 95%; max-height: 95vh; box-shadow: 0 50px 100px rgba(0,0,0,0.1); border-radius: 20px;" />
                                      </body>
                                    </html>
                                  `);
                                }
                              }}
                              className="flex h-14 w-14 items-center justify-center rounded-full bg-white/90 text-black shadow-2xl backdrop-blur-xl hover:bg-white transition-all"
                              title="Open Full Image"
                            >
                              <Maximize2 size={24} />
                            </button>
                            <a
                              href={resultImage}
                              download="style-on-look.png"
                              className="flex h-14 w-14 items-center justify-center rounded-full bg-white/90 text-black shadow-2xl backdrop-blur-xl hover:bg-white transition-all"
                              title="Download Result"
                            >
                              <Download size={24} />
                            </a>
                          </div>
                        </motion.div>
                      ) : isProcessing ? (
                        <motion.div
                          key="loading"
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          exit={{ opacity: 0 }}
                          className="flex h-full w-full flex-col items-center justify-center gap-10 fashion-gradient p-12 text-center"
                        >
                          <div className="relative">
                            <motion.div
                              animate={{
                                scale: [1, 1.3, 1],
                                opacity: [0.2, 0.5, 0.2],
                              }}
                              transition={{ duration: 3, repeat: Infinity }}
                              className="absolute -inset-12 rounded-full bg-fashion-gold/30 blur-3xl"
                            />
                            <div className="relative flex h-32 w-32 items-center justify-center rounded-full border border-white/10 bg-white/5 backdrop-blur-2xl">
                              <Loader2 className="h-12 w-12 animate-spin text-fashion-gold" />
                            </div>
                          </div>
                          <div className="space-y-6">
                            <h4 className="font-serif text-3xl font-light text-white italic tracking-wide">
                              {loadingMessage}
                            </h4>
                            <div className="mx-auto h-1 w-48 overflow-hidden rounded-full bg-white/10">
                              <motion.div
                                animate={{ x: [-192, 192] }}
                                transition={{
                                  duration: 2,
                                  repeat: Infinity,
                                  ease: "linear",
                                }}
                                className="h-full w-full bg-fashion-gold shadow-[0_0_15px_rgba(212,175,55,0.5)]"
                              />
                            </div>
                            <p className="text-[10px] font-bold uppercase tracking-[0.4em] text-gray-500">
                              Neural Synthesis in Progress
                            </p>
                          </div>
                        </motion.div>
                      ) : (
                        <motion.div
                          key="placeholder"
                          className="flex h-full w-full flex-col items-center justify-center gap-8 p-12 text-center"
                        >
                          <div className="relative">
                            <div className="absolute -inset-4 rounded-full bg-gray-50 blur-xl" />
                            <div className="relative rounded-full bg-white p-12 text-gray-100 shadow-inner">
                              <ImageIcon size={80} strokeWidth={0.5} />
                            </div>
                          </div>
                          <div className="space-y-3">
                            <h4 className="font-serif text-2xl font-bold uppercase tracking-widest text-gray-300">
                              Awaiting Creation
                            </h4>
                            <p className="text-xs text-gray-400 max-w-[200px] mx-auto leading-relaxed">
                              Upload your photos to begin the neural
                              transformation.
                            </p>
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                </div>
              </div>
            </motion.div>
          ) : activeTab === "chat" ? (
            <motion.div
              key="chat"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="h-full w-full"
            >
              <FashionChat />
            </motion.div>
          ) : (
            <motion.div
              key="history"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="space-y-8"
            >
              <header className="flex items-center justify-between">
                <div>
                  <h2 className="text-3xl font-bold tracking-tight">
                    Your Gallery
                  </h2>
                  <p className="text-sm text-gray-500">
                    Review and compare your generated fashion looks.
                  </p>
                </div>
                {history.length > 0 && (
                  <div className="relative">
                    <button
                      onClick={() => setShowClearConfirm(!showClearConfirm)}
                      className="flex items-center gap-2 text-xs font-bold text-red-500 hover:underline"
                    >
                      <Trash2 size={14} />
                      Clear All
                    </button>

                    <AnimatePresence>
                      {showClearConfirm && (
                        <motion.div
                          initial={{ opacity: 0, y: 10 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0, y: 10 }}
                          className="absolute right-0 top-full z-10 mt-2 w-48 rounded-xl bg-white p-4 shadow-xl border border-black/5"
                        >
                          <p className="text-[10px] font-bold text-gray-500 mb-3">
                            Are you sure?
                          </p>
                          <div className="flex gap-2">
                            <button
                              onClick={clearHistory}
                              className="flex-1 rounded-lg bg-red-500 py-2 text-[10px] font-bold text-white hover:bg-red-600"
                            >
                              Yes, Clear
                            </button>
                            <button
                              onClick={() => setShowClearConfirm(false)}
                              className="flex-1 rounded-lg bg-gray-100 py-2 text-[10px] font-bold text-gray-500 hover:bg-gray-200"
                            >
                              Cancel
                            </button>
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                )}
              </header>

              {history.length === 0 ? (
                <div className="flex h-96 flex-col items-center justify-center gap-4 rounded-[3rem] border-2 border-dashed border-gray-100 bg-white">
                  <div className="rounded-full bg-gray-50 p-8 text-gray-300">
                    <History size={48} strokeWidth={1} />
                  </div>
                  <div className="text-center">
                    <p className="font-bold">No history yet</p>
                    <p className="text-sm text-gray-400">
                      Your generated looks will appear here.
                    </p>
                  </div>
                  <button
                    onClick={() => setActiveTab("create")}
                    className="mt-2 rounded-full bg-black px-6 py-2 text-xs font-bold text-white shadow-lg"
                  >
                    Go to Studio
                  </button>
                </div>
              ) : (
                <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
                  {history.map((item) => (
                    <motion.div
                      layout
                      key={item._id || item.id}
                      className="group relative flex flex-col overflow-hidden rounded-[2rem] bg-white shadow-sm border border-black/5 transition-all hover:shadow-xl"
                    >
                      <div className="relative aspect-[3/4] overflow-hidden">
                        <img
                          src={item.resultPreview}
                          alt="Result"
                          className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-110"
                          referrerPolicy="no-referrer"
                        />
                        <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent p-6 opacity-0 transition-opacity group-hover:opacity-100">
                          <div className="flex items-center justify-between">
                            <div className="flex gap-2">
                              <button
                                onClick={() => {
                                  setPersonImage({
                                    file: null,
                                    preview: item.personPreview,
                                  });
                                  setClothingImage({
                                    file: null,
                                    preview: item.clothingPreview,
                                  });
                                  setResultImage(item.resultPreview);
                                  setActiveTab("create");
                                }}
                                className="rounded-lg bg-white/20 p-2 text-white backdrop-blur-md hover:bg-white/40"
                                title="Edit/Re-run"
                              >
                                <RefreshCw size={16} />
                              </button>
                              <a
                                href={item.resultPreview}
                                download={`look-${item._id || item.id}.png`}
                                className="rounded-lg bg-white/20 p-2 text-white backdrop-blur-md hover:bg-white/40"
                                title="Download"
                              >
                                <Download size={16} />
                              </a>
                            </div>
                            <button
                              onClick={() =>
                                deleteHistoryItem(item._id || item.id)
                              }
                              className="rounded-lg bg-red-500/20 p-2 text-red-200 backdrop-blur-md hover:bg-red-500/40"
                              title="Delete"
                            >
                              <Trash2 size={16} />
                            </button>
                          </div>
                        </div>
                      </div>
                      <div className="p-4">
                        <div className="flex items-center justify-between">
                          <span className="text-[10px] font-bold uppercase tracking-widest text-gray-400">
                            {new Date(item.timestamp).toLocaleDateString()}
                          </span>
                          <span className="rounded-full bg-gray-100 px-2 py-0.5 text-[8px] font-bold uppercase text-gray-500">
                            {item.fit}
                          </span>
                        </div>
                        <div className="mt-3 flex gap-2">
                          <img
                            src={item.personPreview}
                            className="h-8 w-8 rounded-lg object-cover border border-black/5"
                            referrerPolicy="no-referrer"
                          />
                          <img
                            src={item.clothingPreview}
                            className="h-8 w-8 rounded-lg object-cover border border-black/5"
                            referrerPolicy="no-referrer"
                          />
                          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gray-50 text-gray-300">
                            <Maximize2 size={12} />
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Footer */}
      {activeTab !== "chat" && (
        <footer className="bg-fashion-black pt-24 pb-12 text-white">
          <div className="mx-auto max-w-7xl px-6">
            <div className="grid gap-16 lg:grid-cols-2">
              <div className="space-y-12">
                <div className="flex items-center gap-4">
                  <div className="flex h-16 w-16 items-center justify-center rounded-full bg-fashion-gold text-white shadow-2xl">
                    <Sparkles size={32} />
                  </div>
                  <div>
                    <h2 className="font-serif text-3xl font-bold tracking-tight">
                      STYLE-ON
                    </h2>
                    <p className="text-xs font-bold uppercase tracking-[0.4em] text-gray-500">
                      Neural Fashion House
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-12 sm:grid-cols-3">
                  <div className="space-y-6">
                    <h4 className="text-[10px] font-bold uppercase tracking-widest text-fashion-gold">
                      Maison
                    </h4>
                    <ul className="space-y-4 text-sm text-gray-400">
                      <li>
                        <a
                          href="#"
                          className="hover:text-white transition-colors"
                        >
                          The Studio
                        </a>
                      </li>
                      <li>
                        <a
                          href="#"
                          className="hover:text-white transition-colors"
                        >
                          Neural Engine
                        </a>
                      </li>
                      <li>
                        <a
                          href="#"
                          className="hover:text-white transition-colors"
                        >
                          Sustainability
                        </a>
                      </li>
                      <li>
                        <a
                          href="#"
                          className="hover:text-white transition-colors"
                        >
                          Careers
                        </a>
                      </li>
                    </ul>
                  </div>
                  <div className="space-y-6">
                    <h4 className="text-[10px] font-bold uppercase tracking-widest text-fashion-gold">
                      Services
                    </h4>
                    <ul className="space-y-4 text-sm text-gray-400">
                      <li>
                        <a
                          href="#"
                          className="hover:text-white transition-colors"
                        >
                          Digital Stylist
                        </a>
                      </li>
                      <li>
                        <a
                          href="#"
                          className="hover:text-white transition-colors"
                        >
                          Virtual Fitting
                        </a>
                      </li>
                      <li>
                        <a
                          href="#"
                          className="hover:text-white transition-colors"
                        >
                          API Access
                        </a>
                      </li>
                      <li>
                        <a
                          href="#"
                          className="hover:text-white transition-colors"
                        >
                          Concierge
                        </a>
                      </li>
                    </ul>
                  </div>
                  <div className="space-y-6">
                    <h4 className="text-[10px] font-bold uppercase tracking-widest text-fashion-gold">
                      Legal
                    </h4>
                    <ul className="space-y-4 text-sm text-gray-400">
                      <li>
                        <a
                          href="#"
                          className="hover:text-white transition-colors"
                        >
                          Privacy
                        </a>
                      </li>
                      <li>
                        <a
                          href="#"
                          className="hover:text-white transition-colors"
                        >
                          Terms
                        </a>
                      </li>
                      <li>
                        <a
                          href="#"
                          className="hover:text-white transition-colors"
                        >
                          Ethics
                        </a>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>

              <div className="space-y-12 rounded-[3rem] bg-white/5 p-12 backdrop-blur-xl border border-white/10">
                <div className="space-y-4">
                  <h3 className="font-serif text-3xl font-bold">
                    Join the{" "}
                    <span className="italic text-fashion-gold">
                      Avant-Garde
                    </span>
                  </h3>
                  <p className="text-sm leading-relaxed text-gray-400">
                    Subscribe to receive early access to new neural models and
                    exclusive fashion drops.
                  </p>
                </div>

                <div className="flex gap-2">
                  <input
                    type="email"
                    placeholder="Email Address"
                    className="flex-1 rounded-full bg-white/10 border border-white/10 px-8 py-4 text-sm focus:outline-none focus:ring-2 focus:ring-fashion-gold/50 transition-all"
                  />
                  <button className="rounded-full bg-fashion-gold px-8 py-4 text-[10px] font-bold uppercase tracking-widest text-white shadow-xl hover:scale-105 transition-all">
                    Join
                  </button>
                </div>

                <div className="flex gap-6">
                  {["Instagram", "Twitter", "LinkedIn", "TikTok"].map(
                    (social) => (
                      <a
                        key={social}
                        href="#"
                        className="text-[10px] font-bold uppercase tracking-widest text-gray-500 hover:text-fashion-gold transition-colors"
                      >
                        {social}
                      </a>
                    ),
                  )}
                </div>
              </div>
            </div>

            <div className="mt-24 flex flex-col items-center justify-between gap-8 border-t border-white/5 pt-12 text-[10px] font-bold uppercase tracking-[0.2em] text-gray-600 sm:flex-row">
              <p>© 2026 STYLE-ON NEURAL HOUSE. ALL RIGHTS RESERVED.</p>
              <div className="flex gap-8">
                <a href="#" className="hover:text-white transition-colors">
                  Cookies
                </a>
                <a href="#" className="hover:text-white transition-colors">
                  Accessibility
                </a>
                <a href="#" className="hover:text-white transition-colors">
                  Sitemap
                </a>
              </div>
            </div>
          </div>
        </footer>
      )}
    </div>
  );
}
