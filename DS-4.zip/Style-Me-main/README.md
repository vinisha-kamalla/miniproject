# 👗 StyleOn – AI-Based Virtual Try-On & Fashion Assistant

StyleOn is an AI-powered fashion platform that allows users to visualize outfits using virtual try-on and get personalized styling suggestions through a chatbot.

---

## 🚀 Features

- 🧍 Virtual Try-On using AI-generated images
- 🤖 Chatbot for fashion recommendations
- 📸 Upload user images and try different outfits
- 🔐 Secure authentication using Firebase
- ☁️ Cloud storage for generated images
- ⚡ Fast API-based AI processing (Gemini API)

---

## 🛠️ Tech Stack

- **Frontend:** React.js, Tailwind CSS
- **Backend:** Node.js (API handling)
- **AI Services:** Gemini API (Image generation + Chatbot)
- **Database & Auth:** Firebase (Authentication + Storage)
- **API Communication:** Fetch / Axios

---

## 📌 How It Works

1. User uploads an image
2. User selects a clothing item
3. Image + selection is sent to AI API
4. AI generates virtual try-on image
5. Result is displayed to the user
6. User interacts with chatbot for styling advice

---

## ⚙️ Setup Instructions

### Prerequisites

- Node.js installed
- Gemini API Key

---

### Installation

1. Clone the repository:

```bash
git clone https://github.com/your-username/styleon.git
cd styleon
```
